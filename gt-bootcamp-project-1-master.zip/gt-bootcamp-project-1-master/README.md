# Ruth Holliday, Austin Little, Gina Kim, Nathalie Longstreet, Minqiu Yu &  Kimberly Gordon's first project for
# the Georgia Tech Data Analysis Bootcamp

